package com.nagarro.app.service;
 import org.springframework.stereotype.Service;

 @Service
 public class FileProcessingService {
//     private final FileProcessor pumaFileProcessor;
//     private final FileProcessor nikeFileProcessor;

     public FileProcessingService() {
//         this.pumaFileProcessor = new FileProcessor("Puma.csv");
//         this.nikeFileProcessor = new FileProcessor("Nike.csv");
     }

//     @Scheduled(fixedRate = 30000)
//     public void processPumaFile() {
//         pumaFileProcessor.run();
//     }
//
//     @Scheduled(fixedRate = 30000)
//     public void processNikeFile() {
//         nikeFileProcessor.run();
//     }
 }

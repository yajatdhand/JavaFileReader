package com.nagarro.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nagarro.app.models.ProductId;
import com.nagarro.app.models.Puma;

@Repository
public interface PumaRepository extends JpaRepository<Puma, ProductId> {

	@Query(value = "SELECT * FROM Puma p WHERE " + "p.brand = :brand AND "
			+ "p.color = COALESCE(:color, p.color) AND " + "p.size = COALESCE(:size, p.size)", nativeQuery = true)
	List<Puma> filterData(@Param("brand") String brand, @Param("color") String color, @Param("size") Integer size,
			@Param("type") String type);

}

//package com.nagarro.app.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//
//import com.nagarro.app.processor.FileProcessor;
//
//@EnableScheduling
//public class ProductController {
//
//	@Autowired
//	FileProcessor nikeFileProcessor;
//
//	@Autowired
//	FileProcessor pumaFileProcessor;
//	
//	@Scheduled(fixedRate = 30000)
//	public void processNikeFile() {
//		nikeFileProcessor.setFilepath("Nike.csv");
//		nikeFileProcessor.run();
//	}
//
//	@Scheduled(fixedRate = 30000)
//	public void processPumaFile() {
//		pumaFileProcessor.setFilepath("Puma.csv");
//		pumaFileProcessor.run();
//	}
//
//}

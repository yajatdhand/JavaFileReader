package com.nagarro.app.service.impl;

import com.nagarro.app.service.PumaService;

public class PumaServiceImpl implements PumaService{

}

package com.nagarro.app.models;

public enum ProductType {
    SHIRT,
    SHOES
}

package com.nagarro.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nagarro.app.processor.FileProcessor;
import com.nagarro.app.service.impl.FileReaderServiceImpl;

@Configuration
public class AppConfig {

    @Bean
    FileProcessor fileProcessor() {
		return new FileProcessor();
	}
    
    @Bean
    FileReaderServiceImpl fileReaderServiceImpl() {
		return new FileReaderServiceImpl();
	}
}

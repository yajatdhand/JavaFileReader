package com.nagarro.app.service.impl;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.app.models.Nike;
import com.nagarro.app.models.Puma;
import com.nagarro.app.repository.NikeRepository;
import com.nagarro.app.repository.PumaRepository;
import com.nagarro.app.service.FileReaderService;

@Service
public class FileReaderServiceImpl implements FileReaderService {

	@Autowired
	private NikeRepository nikeRepository;

	@Autowired
	private PumaRepository pumaRepository;

	@Override
	public void run() {

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Are you searching something? (yes/no)");
			String nextSearch = sc.nextLine();

			if (nextSearch.equalsIgnoreCase("no")) {
				System.out.println("Bye... !!!");
				break;
			}

			// Search logic
			System.out.println("Please Enter brand for search : ");
			String brand = sc.nextLine();

			System.out.println("Please Enter color for search : ");
			String color = sc.nextLine();

			System.out.println("Please Enter size for search : ");
			int size = sc.nextInt();

			if (!brand.isBlank()) {
				System.out.println("Filter products : ");
				if (brand.equalsIgnoreCase("nike")) {
					System.out.println("result "+nikeRepository.filterData(brand, color, size, color));
					showNikeData(nikeRepository.filterData(brand, color, size, color));
				} else {
					showPumaData(pumaRepository.filterData(brand, color, size, color));
				}
			}
		}
	}

	private void showNikeData(List<Nike> filterData) {
		filterData.stream().forEach(nike -> System.out.println(nike));
	}

	private void showPumaData(List<Puma> filterData) {
		filterData.stream().forEach(puma -> System.out.println(puma));
	}

}

package com.nagarro.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.nagarro.app.processor.FileProcessor;
import com.nagarro.app.service.FileReaderService;

@SpringBootApplication
@EnableScheduling
public class FileReaderApplication implements CommandLineRunner {

	@Autowired
	private FileReaderService service;

	@Autowired
	private FileProcessor nikeFileProcessor;

	@Autowired
	private FileProcessor pumaFileProcessor;

	@Scheduled(fixedRate = 30000)
	public void processNikeFile() {
		nikeFileProcessor.setFilepath("Nike.csv");
		nikeFileProcessor.run();
	}

	@Scheduled(fixedRate = 30000)
	public void processPumaFile() {
		pumaFileProcessor.setFilepath("Puma.csv");
		pumaFileProcessor.run();
	}

	public static void main(String[] args) {
		SpringApplication.run(FileReaderApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		service.run();
	}
}

package com.nagarro.app.service;

public interface FileReaderService {

	public void run();
	
}

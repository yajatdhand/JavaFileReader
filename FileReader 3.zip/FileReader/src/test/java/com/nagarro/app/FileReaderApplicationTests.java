package com.nagarro.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
